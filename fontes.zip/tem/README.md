# sistema-de-cadastro
O sistema feito em PHP com BootStrap, HTML5, JavaScript, este sistema serve para uma escola que queira cadastrar os seus alunos, professores e parceiros. O funcionamento do sistema se aplica em conexao.php e o sql contido na basta db.
